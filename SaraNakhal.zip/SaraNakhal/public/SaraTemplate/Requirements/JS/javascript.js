$(document).ready(function () {
    ScrollEvent()
    $('.ScrollerBtn').on('click', ScrollBackUp);
    Sliders()
    if($('.SubscriptionMessageItem').length != 0){
        const target = document.querySelector('.SubscriptionMessage');
        if (target) {
            lenis.scrollTo(target); // simple scroll to element
        }
    }
    if($('.FAQItem').length != 0){
        $('.FAQItem').first().click()
    }
});

$(window).on('load', function () {
    $('.PreloaderInner').addClass('animate__fadeOutUp')

    SetSrc()
    SetBg()
    if ($(window).width() < 1200) {
        Consoles()
    }
});

$(window).on('resize', function () {

});

window.ScrollEvent = function () {
    window.lenis = new Lenis({
        duration: 1.0,
        easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
        smooth: true,
    });

    function raf(time) {
        window.lenis.raf(time);
        var Scroll = window.lenis.scroll,
            dh = document.documentElement.scrollHeight,
            wh = window.innerHeight,
            value = (Scroll / (dh - wh)) * 100;

        $('.ScrollIndicatorAmount').width(value + '%');
        $('.BannerDiv').css('right', value + '%');

        if (Scroll > 500) {
            $('.ScrollerBtn').fadeIn(600);
        } else {
            $('.ScrollerBtn').fadeOut(600);
        }

        requestAnimationFrame(raf);
    }

    requestAnimationFrame(raf);
};

function SetBg() {
    $('.setbg').each(function () {
        var el = $(this);
        var bg = el.attr('rel');
        el.css('background-image', 'url("' + bg + '")')
        el.removeAttr('rel')
    });
}
function SetSrc() {
    $('.setsrc').each(function () {
        var el = $(this);
        var bg = el.attr('rel');
        el.attr('src', bg)
        el.removeAttr('rel')
    });
}
function Sliders() {
    $('.ReviewsSlider').slick({
        dots: false,
        arrows: false,
        autoplay: true,
        autoplaySpeed: 3000,
        infinite: true,
        speed: 300,
        slidesToShow: 3,
        slidesToScroll: 3,
        responsive: [
            {
                breakpoint: 1200,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
            },
            {
                breakpoint: 800,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    });

    $('.OurPartnersSlider').slick({
        dots: false,
        arrows: false,
        autoplay: true,
        autoplaySpeed: 3000,
        infinite: true,
        speed: 300,
        slidesToShow: 4,
        slidesToScroll: 4,
        responsive: [
            {
                breakpoint: 1200,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
            }
        ]
    });

    AOS.init();
}

function StartBrowsing(){
    const target = document.querySelector('.AboutBrief');
    if (target) {
        lenis.scrollTo(target); // simple scroll to element
    }
}

function ScrollBackUp() {
    window.lenis.scrollTo(0, {duration: 1.5});
}
function PlayVideo(el){
    var Src = el.find('a').attr('href');
    $('.VideoPlayer video').attr('src',Src)
    $('.VideoPlayer').show()
}
function ClearVideoPlayer(){
    $('.VideoPlayer').fadeOut(600)
    $('.VideoPlayer video').attr('src','')
}
function GetSideMenuTabs() {
    var TabsHTML = $('.HeaderTabs ul').html();
    var SideMenuCloseFunction = function() {
        $('.SideMenuFade')[0].click();
    };

    $('.SideMenuDiv ul').html(TabsHTML);

    $('.SideMenuDiv ul li').each(function(index, el) {
        $(el).on('click', function(e) {
            var original = el.getAttribute('onclick');
            if (original) {
                eval(original);
            }
            SideMenuCloseFunction();
        });
    });

    $('.HeaderTabs').html('');
}

function Consoles(){
    GetSideMenuTabs()
}
function ToggleFAQ(el){
    if(el.hasClass('OpenedFAQItem')){
        $('.FAQItem').removeClass('OpenedFAQItem')
    }else{
        $('.FAQItem').removeClass('OpenedFAQItem')
        el.addClass('OpenedFAQItem')
    }
}

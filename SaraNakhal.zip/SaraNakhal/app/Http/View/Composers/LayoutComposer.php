<?php

namespace App\Http\View\Composers;

use App\Models\Info;
use Illuminate\View\View;

class LayoutComposer
{
    /**
     * Bind data to the view.
     *
     * @param  View  $view
     * @return void
     */
    public function compose(View $view)
    {
        $info     = Info::first();

        $view->with('GlobalInfo', $info);
    }
}

<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\Article;
use Illuminate\Http\Request;

class HomePageController extends Controller
{
    public function index(Request $request)
    {
        $articles = Article::orderBy('id', 'desc')->get();

        return view('client.home', compact( 'articles'));
    }

}

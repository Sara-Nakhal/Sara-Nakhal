<?php

return [
    'site_title' => \App\Models\Info::first()->title ?? '',
];

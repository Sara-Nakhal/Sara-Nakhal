<!DOCTYPE html>
<html lang="eng" translate="no">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    {{-- Dynamic Titles & Meta --}}
    @if(request()->routeIs('articles.show'))
        <title>{{ $article->title ?? '' }} - {{ $GlobalInfo->title ?? '' }}</title>
        <meta name="description" content="{{ Str::limit($article->description ?? $article->title, 155) }}">
        <meta property="og:title" content="{{ $article->title ?? '' }} - {{ $GlobalInfo->title ?? '' }}">
        <meta property="og:description" content="{{ Str::limit($article->description ?? $article->title, 155) }}">
        <meta property="og:image" content="{{ $article->photo->thumbnail ?? asset('SaraTemplate/Requirements/IMG/Thumb.jpg') }}">
    @else
        <title>{{ $GlobalInfo->title ?? '' }}</title>
        <meta property="og:title" content="{{ $GlobalInfo->title ?? '' }}">
        <meta property="og:image" content="{{ asset('SaraTemplate/Requirements/IMG/Thumb.jpg') }}">
    @endif

    {{-- Canonical --}}
    <link rel="canonical" href="{{ url()->current() }}" />

    {{-- Open Graph --}}
    <meta property="og:type" content="website">
    <meta property="og:url" content="{{ url()->current() }}">
    <meta property="og:site_name" content="{{ $GlobalInfo->title ?? '' }}">

    {{-- Twitter Cards --}}
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="@yield('meta_title', $GlobalInfo->title ?? '')">
    <meta name="twitter:image" content="@yield('meta_image', asset('SaraTemplate/Requirements/IMG/Thumb.jpg'))">

    {{-- Favicon --}}
    <link rel="icon" type="image/x-icon" href="{{ $GlobalInfo->favicon->thumbnail ?? asset('SaraTemplate/Requirements/IMG/Thumb.jpg') }}">
    <link rel="apple-touch-icon" href="{{ $GlobalInfo->favicon->thumbnail ?? asset('SaraTemplate/Requirements/IMG/Thumb.jpg') }}">

    {{-- Fonts & Styles --}}
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link rel="stylesheet" href="{{ asset('SaraTemplate/Requirements/CSS/style.css') }}">
    @yield('styles')
    <link rel="stylesheet" href="{{ asset('SaraTemplate/Requirements/CSS/ipad.css') }}">
    <link rel="stylesheet" href="{{ asset('SaraTemplate/Requirements/CSS/mobile.css') }}">
</head>
<body>
<header>
    <div class="container">
        <div class="HeaderInner">
            <div class="HeaderLogoParent">
                <div class="HeaderLogo" onclick="$(this).find('a')[0].click()">
                    <a href="{{ route('home') }}" class="d-none"></a>
                    <div class="Shine"></div>
                    <img src="{{ $GlobalInfo->logo->thumbnail ?? '' }}" alt="{{ $GlobalInfo->title ?? '' }} - {{ $GlobalInfo->keywords ?? '' }} - {{ $GlobalInfo->about->description ?? '' }}">
                </div>
                <h6 onclick="$(this).find('a')[0].click()">
                    <a href="tel:{{ $GlobalInfo->phone ?? '' }}" class="d-none"></a>
                    <div class="setbg" rel="{{ asset('') }}SaraTemplate/Requirements/IMG/PhoneRed.png"></div>
                    {{ $GlobalInfo->phone ?? '' }}
                </h6>
            </div>

            <div class="HeaderTabs">
                <ul>
                    <li onclick="$(this).find('a')[0].click()">
                        <a href="{{ route('home') }}" class="d-none"></a>
                        Home
                    </li>
                    @foreach(config('panel.available_languages') as $langLocale => $langName)
                        @if(app()->getLocale() != $langLocale)
                            <li onclick="$(this).find('a')[0].click()">
                                <a class="d-none" href="{{ url()->current() }}?change_language={{ $langLocale }}">
                                </a>
                                {{ strtoupper($langLocale) }}
                                ({{ $langName }})
                            </li>
                        @endif
                    @endforeach
                </ul>
            </div>

            <button type="button" class="SideMenuBtn" onclick="$('.SideMenu').show()">
                <div class="setbg" rel="{{ asset('') }}SaraTemplate/Requirements/IMG/Menu.png"></div>
            </button>
        </div>
    </div>
</header>

<main>
    @yield('content')
</main>

<footer>

    <div class="FooterInner">
        <div class="container">
            <div class="row">
                <!-- About Section -->
                <div class="col-lg-4 col-sm-12">
                    <div class="FooterVision">
                        <img src="{{ $GlobalInfo->footer->thumbnail ?? '' }}" alt="{{ $GlobalInfo->title ?? '' }} - {{ $GlobalInfo->vision ?? '' }} - {{ $GlobalInfo->about->description ?? '' }}">
                        <p>
                            {{ $GlobalInfo->vision ?? '' }}
                        </p>

                    </div>
                </div>

                <!-- Quick Links -->
                <div class="col-lg-4 col-sm-12">
                    <div class="FooterQuickLinks">
                        <h4>Quick Links</h4>
                        <ul>
                            <li onclick="$(this).find('a')[0].click()">
                                Home
                                <div class="setbg" rel="{{ asset('') }}SaraTemplate/Requirements/IMG/Right.png" onclick="$(this).find('a')[0].click()">
                                    <a href="{{ route('home') }}" class="d-none"></a></div>
                            </li>
                        </ul>
                    </div>
                </div>

                <!-- Contact Info & Services -->
                <div class="col-lg-4 col-sm-12">
                    <div class="FooterContact">
                        <h4>Contact Us</h4>

                        <label>
                            <i class="fa fa-map-marker-alt"></i>
                            {{ $GlobalInfo->address ?? '' }}
                        </label>

                        <label onclick="$(this).find('a')[0].click()" style="cursor: pointer">
                            <a href="tel:{{ $GlobalInfo->phone ?? '' }}" class="d-none"></a>
                            <i class="fa fa-phone"></i> Phone: {{ $GlobalInfo->phone ?? '' }}
                        </label>

                        <label onclick="$(this).find('a')[0].click()" style="cursor: pointer">
                            <a href="mailto:{{ $GlobalInfo->email ?? '' }}" class="d-none"></a>
                            <i class="fa fa-envelope"></i> Email: {{ $GlobalInfo->email ?? '' }}
                        </label>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="CopyRights d-none">
        <div class="container">
            <p>
                &copy; {{ date('Y') }} - All rights reserved.
                | Designed & Developed by <a href="#" target="_blank">Sara LLC</a>
            </p>
        </div>
    </div>
</footer>

<div class="MobileCallBtn">
    <button type="button" class="animate__animated animate__flipInX" onclick="$(this).find('a')[0].click()">
        <div class="Shine"></div>
        <a href="tel:{{ $GlobalInfo->phone ?? '' }}" class="d-none"></a>
        <div class="setbg" rel="{{ asset('') }}SaraTemplate/Requirements/IMG/PhoneRed.png"></div>
    </button>
</div>

<div class="ScrollerBtn">
    <button type="button" class="animate__animated animate__flipInX">
        <div class="setbg" rel="{{ asset('') }}SaraTemplate/Requirements/IMG/Up.png"></div>
    </button>
</div>

<div class="ScrollIndicatorAmount"></div>

<div class="SideMenu">
    <div class="SideMenuInner">
        <div class="SideMenuFade" onclick="$('.SideMenu').fadeOut(600)"></div>
        <div class="SideMenuDiv animate__animated animate__fadeInRight">
            <div class="SideMenuLogo" onclick="$(this).find('a')[0].click()">
                <div class="Shine"></div>
                <img src="{{ $GlobalInfo->logo->thumbnail ?? '' }}" alt="{{ $GlobalInfo->title ?? '' }} - {{ $GlobalInfo->keywords ?? '' }} - {{ $GlobalInfo->about->description ?? '' }}">
            </div>
            <ul></ul>
        </div>
    </div>
</div>

<div class="VideoPlayer">
    <div class="VideoPlayerInner">
        <div class="VideoPlayerFade" onclick="ClearVideoPlayer()"></div>
        <div class="VideoPlayerDiv animate__animated animate__zoomIn">
            <video autoplay playsinline controls loop></video>
            <div class="VideoCloser">
                <button class="" type="button" onclick="ClearVideoPlayer()">
                    <i class="fa fa-times-circle"></i>
                    Close Video
                </button>
            </div>
        </div>
    </div>
</div>

<div class="Preloader">
    <div class="PreloaderInner animate__animated">
        <div class="PreloaderDiv">
            <div class="PreloaderLoader"></div>
            <img src="{{ $GlobalInfo->logo->thumbnail ?? '' }}" alt="{{ $GlobalInfo->title ?? '' }} - {{ $GlobalInfo->keywords ?? '' }} - {{ $GlobalInfo->about->description ?? '' }}">
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="{{ asset('') }}SaraTemplate/Requirements/JS/numscroller-1.0.js"></script>
<script type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="https://unpkg.com/lenis@1.3.4/dist/lenis.min.js"></script>
<script src="{{ asset('') }}SaraTemplate/Requirements/JS/javascript.js"></script>
@yield('scripts')
</body>
</html>


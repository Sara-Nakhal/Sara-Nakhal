<aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">
        @can('info_access')
            <li class="nav-item">
                <a href="{{ route("admin.info.index") }}"
                   class="nav-link {{ request()->is('admin/info') || request()->is('admin/info/*') ? 'active' : 'collapsed' }}">
                    <i class="fa-fw fas fa-info-circle"></i>
                    <span>{{ trans('cruds.info.title') }}</span>
                </a>
            </li>
        @endcan
        @can('category_access')
            <li class="nav-item">
                <a href="{{ route("admin.categories.index") }}"
                   class="nav-link {{ request()->is('admin/categories') || request()->is('admin/categories/*') ? 'active' : 'collapsed' }}">
                    <i class="fas fa-th-large fa-fw"></i>
                    <span>{{ trans('cruds.category.title') }}</span>
                </a>
            </li>
        @endcan
        @can('article_access')
            <li class="nav-item">
                <a href="{{ route("admin.articles.index") }}"
                   class="nav-link {{ request()->is('admin/articles') || request()->is('admin/articles/*') ? 'active' : 'collapsed' }}">
                    <i class="fas fa-paperclip fa-fw"></i>
                    {{ trans('cruds.article.title') }}
                </a>
            </li>
        @endcan
        @foreach(config('panel.available_languages') as $langLocale => $langName)
            @if(app()->getLocale() != $langLocale)
                <li class="nav-item">
                    <a href="{{ url()->current() }}?change_language={{ $langLocale }}" class="nav-link collapsed">
                        <i class="fas fa-language fa-fw"></i>
                        {{ strtoupper($langLocale) }}
                        ({{ $langName }})
                    </a>
                </li>
            @endif
        @endforeach


        @can('user_management_access')
            <li class="nav-item {{ request()->is('admin/permissions*') ? 'menu-open' : '' }} {{ request()->is('admin/roles*') ? 'menu-open' : '' }} {{ request()->is('admin/users*') ? 'menu-open' : '' }}">
                <a class="nav-link collapsed" data-bs-target="#user_management_access" data-bs-toggle="collapse"
                   href="#">
                    <i class="fa-fw fas fa-users"></i><span>{{ trans('cruds.userManagement.title') }}</span><i
                        class="bi bi-chevron-down ms-auto"></i>
                </a>
                <ul id="user_management_access"
                    class="nav-content collapse {{ request()->is('admin/permissions*') ? 'show' : '' }} {{ request()->is('admin/roles*') ? 'show' : '' }} {{ request()->is('admin/users*') ? 'show' : '' }}"
                    data-bs-parent="#sidebar-nav">
                    @can('permission_access')
                        <li class="nav-item">
                            <a href="{{ route("admin.permissions.index") }}"
                               class="nav-link {{ request()->is('admin/permissions') || request()->is('admin/permissions/*') ? 'active' : 'collapsed' }}">
                                <i class="fa-fw fas fa-unlock-alt">

                                </i>
                                <span>{{ trans('cruds.permission.title') }}</span>
                            </a>
                        </li>
                    @endcan
                    @can('role_access')
                        <li class="nav-item">
                            <a href="{{ route("admin.roles.index") }}"
                               class="nav-link {{ request()->is('admin/roles') || request()->is('admin/roles/*') ? 'active' : 'collapsed' }}">
                                <i class="fa-fw fas fa-briefcase">

                                </i>
                                <span>{{ trans('cruds.role.title') }}</span>
                            </a>
                        </li>
                    @endcan
                    @can('user_access')
                        <li class="nav-item">
                            <a href="{{ route("admin.users.index") }}"
                               class="nav-link {{ request()->is('admin/users') || request()->is('admin/users/*') ? 'active' : 'collapsed' }}">
                                <i class="fa-fw fas fa-user">

                                </i>
                                <span>{{ trans('cruds.user.title') }}</span>
                            </a>
                        </li>
                    @endcan
                </ul>
            </li><!-- End Forms Nav -->
        @endcan

    </ul>

</aside><!-- End Sidebar-->

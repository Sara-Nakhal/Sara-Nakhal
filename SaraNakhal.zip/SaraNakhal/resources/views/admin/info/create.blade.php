@extends('layouts.customize-admin')
@section('content')

    <div class="card">
        <div class="card-header">
            {{ trans('global.create') }} {{ trans('cruds.info.title_singular') }}
        </div>

        <div class="card-body">
            <form action="{{ route("admin.info.store") }}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="form-group {{ $errors->has('logo') ? 'has-error' : '' }}">
                    <label for="logo">{{ trans('cruds.info.fields.logo') }}</label>
                    <div class="needsclick dropzone" id="logo-dropzone">

                    </div>
                    @if($errors->has('logo'))
                        <em class="invalid-feedback">
                            {{ $errors->first('logo') }}
                        </em>
                    @endif
                    <p class="helper-block">
                        {{ trans('cruds.info.fields.logo_helper') }}
                    </p>
                </div>
                <div class="form-group {{ $errors->has('footer') ? 'has-error' : '' }}">
                    <label for="footer">{{ trans('cruds.info.fields.footer') }}</label>
                    <div class="needsclick dropzone" id="footer-dropzone">

                    </div>
                    @if($errors->has('footer'))
                        <em class="invalid-feedback">
                            {{ $errors->first('footer') }}
                        </em>
                    @endif
                    <p class="helper-block">
                        {{ trans('cruds.info.fields.footer_helper') }}
                    </p>
                </div>
                <div class="form-group {{ $errors->has('favicon') ? 'has-error' : '' }}">
                    <label for="favicon">{{ trans('cruds.info.fields.favicon') }}</label>
                    <div class="needsclick dropzone" id="favicon-dropzone">

                    </div>
                    @if($errors->has('favicon'))
                        <em class="invalid-feedback">
                            {{ $errors->first('favicon') }}
                        </em>
                    @endif
                    <p class="helper-block">
                        {{ trans('cruds.info.fields.favicon_helper') }}
                    </p>
                </div>
                <div class="form-group {{ $errors->has('title_en') ? 'has-error' : '' }}">
                    <label for="title_en">{{ trans('cruds.info.fields.title_en') }}*</label>
                    <input type="text" id="title_en" name="title_en" class="form-control"
                           value="{{ old('title_en', isset($info) ? $info->title_en : '') }}" required>
                    @if($errors->has('title_en'))
                        <em class="invalid-feedback">
                            {{ $errors->first('title_en') }}
                        </em>
                    @endif
                    <p class="helper-block">
                        {{ trans('cruds.info.fields.title_en_helper') }}
                    </p>
                </div>
                <div class="form-group {{ $errors->has('title_ar') ? 'has-error' : '' }}">
                    <label for="title_ar">{{ trans('cruds.info.fields.title_ar') }}*</label>
                    <input type="text" id="title_ar" name="title_ar" class="form-control"
                           value="{{ old('title_ar', isset($info) ? $info->title_ar : '') }}" required>
                    @if($errors->has('title_ar'))
                        <em class="invalid-feedback">
                            {{ $errors->first('title_ar') }}
                        </em>
                    @endif
                    <p class="helper-block">
                        {{ trans('cruds.info.fields.title_ar_helper') }}
                    </p>
                </div>
                <div class="form-group {{ $errors->has('keywords_en') ? 'has-error' : '' }}">
                    <label for="keywords_en">{{ trans('cruds.info.fields.keywords_en') }}*</label>
                    <input type="text" id="keywords_en" name="keywords_en" class="form-control"
                           value="{{ old('keywords_en', isset($info) ? $info->keywords_en : '') }}" required>
                    @if($errors->has('keywords_en'))
                        <em class="invalid-feedback">
                            {{ $errors->first('keywords_en') }}
                        </em>
                    @endif
                    <p class="helper-block">
                        {{ trans('cruds.info.fields.keywords_en_helper') }}
                    </p>
                </div>
                <div class="form-group {{ $errors->has('keywords_ar') ? 'has-error' : '' }}">
                    <label for="keywords_ar">{{ trans('cruds.info.fields.keywords_ar') }}*</label>
                    <input type="text" id="keywords_ar" name="keywords_ar" class="form-control"
                           value="{{ old('keywords_ar', isset($info) ? $info->keywords_ar : '') }}" required>
                    @if($errors->has('keywords_ar'))
                        <em class="invalid-feedback">
                            {{ $errors->first('keywords_ar') }}
                        </em>
                    @endif
                    <p class="helper-block">
                        {{ trans('cruds.info.fields.keywords_ar_helper') }}
                    </p>
                </div>
                <div class="form-group {{ $errors->has('description_en') ? 'has-error' : '' }}">
                    <label for="description_en">{{ trans('cruds.info.fields.description_en') }}*</label>
                    <input type="text" id="description_en" name="description_en" class="form-control"
                           value="{{ old('description_en', isset($info) ? $info->description_en : '') }}" required>
                    @if($errors->has('description_en'))
                        <em class="invalid-feedback">
                            {{ $errors->first('description_en') }}
                        </em>
                    @endif
                    <p class="helper-block">
                        {{ trans('cruds.info.fields.description_en_helper') }}
                    </p>
                </div>
                <div class="form-group {{ $errors->has('description_ar') ? 'has-error' : '' }}">
                    <label for="description_ar">{{ trans('cruds.info.fields.description_ar') }}*</label>
                    <input type="text" id="description_ar" name="description_ar" class="form-control"
                           value="{{ old('description_ar', isset($info) ? $info->description_ar : '') }}" required>
                    @if($errors->has('description_ar'))
                        <em class="invalid-feedback">
                            {{ $errors->first('description_ar') }}
                        </em>
                    @endif
                    <p class="helper-block">
                        {{ trans('cruds.info.fields.description_ar_helper') }}
                    </p>
                </div>
                <div class="form-group {{ $errors->has('vision_en') ? 'has-error' : '' }}">
                    <label for="vision_en">{{ trans('cruds.info.fields.vision_en') }}*</label>
                    <input type="text" id="vision_en" name="vision_en" class="form-control"
                           value="{{ old('vision_en', isset($info) ? $info->vision_en : '') }}" required>
                    @if($errors->has('vision_en'))
                        <em class="invalid-feedback">
                            {{ $errors->first('vision_en') }}
                        </em>
                    @endif
                    <p class="helper-block">
                        {{ trans('cruds.info.fields.vision_en_helper') }}
                    </p>
                </div>
                <div class="form-group {{ $errors->has('vision_ar') ? 'has-error' : '' }}">
                    <label for="vision_ar">{{ trans('cruds.info.fields.vision_ar') }}*</label>
                    <input type="text" id="vision_ar" name="vision_ar" class="form-control"
                           value="{{ old('vision_ar', isset($info) ? $info->vision_ar : '') }}" required>
                    @if($errors->has('vision_ar'))
                        <em class="invalid-feedback">
                            {{ $errors->first('vision_ar') }}
                        </em>
                    @endif
                    <p class="helper-block">
                        {{ trans('cruds.info.fields.vision_ar_helper') }}
                    </p>
                </div>
                <div class="form-group {{ $errors->has('address') ? 'has-error' : '' }}">
                    <label for="address">{{ trans('cruds.info.fields.address') }}*</label>
                    <input type="text" id="address" name="address" class="form-control"
                           value="{{ old('address', isset($info) ? $info->address : '') }}" required>
                    @if($errors->has('address'))
                        <em class="invalid-feedback">
                            {{ $errors->first('address') }}
                        </em>
                    @endif
                    <p class="helper-block">
                        {{ trans('cruds.info.fields.address_helper') }}
                    </p>
                </div>
                <div class="form-group {{ $errors->has('phone') ? 'has-error' : '' }}">
                    <label for="phone">{{ trans('cruds.info.fields.phone') }}*</label>
                    <input type="tel" id="phone" name="phone" class="form-control"
                           value="{{ old('phone', isset($info) ? $info->phone : '') }}" required>
                    @if($errors->has('phone'))
                        <em class="invalid-feedback">
                            {{ $errors->first('phone') }}
                        </em>
                    @endif
                    <p class="helper-block">
                        {{ trans('cruds.info.fields.phone_helper') }}
                    </p>
                </div>
                <div class="form-group {{ $errors->has('email') ? 'has-error' : '' }}">
                    <label for="email">{{ trans('cruds.info.fields.email') }}*</label>
                    <input type="email" id="email" name="email" class="form-control"
                           value="{{ old('email', isset($info) ? $info->email : '') }}" required>
                    @if($errors->has('email'))
                        <em class="invalid-feedback">
                            {{ $errors->first('email') }}
                        </em>
                    @endif
                    <p class="helper-block">
                        {{ trans('cruds.info.fields.email_helper') }}
                    </p>
                </div>
                <div class="form-group {{ $errors->has('map') ? 'has-error' : '' }}">
                    <label for="map">{{ trans('cruds.info.fields.map') }}*</label>
                    <textarea id="map" name="map" class="form-control summernote" required>{{ old('map', isset($info) ? $info->map : '') }}</textarea>
                    @if($errors->has('map'))
                        <em class="invalid-feedback">
                            {{ $errors->first('map') }}
                        </em>
                    @endif
                    <p class="helper-block">
                        {{ trans('cruds.info.fields.map_helper') }}
                    </p>
                </div>
                <div>
                    <input class="btn btn-danger" type="submit" value="{{ trans('global.save') }}">
                </div>
            </form>


        </div>
    </div>
@endsection
@section('scripts')
    <script>
        Dropzone.options.logoDropzone = {
            url: '{{ route('admin.info.storeMedia') }}',
            acceptedFiles: '.jpeg,.jpg,.png,.gif,.webp',
            maxFiles: 1,
            addRemoveLinks: true,
            headers: {
                'X-CSRF-TOKEN': "{{ csrf_token() }}"
            },
            success: function (file, response) {
                $('form').find('input[name="logo"]').remove()
                $('form').append('<input type="hidden" name="logo" value="' + response.name + '">')
            },
            removedfile: function (file) {
                file.previewElement.remove()
                if (file.status !== 'error') {
                    $('form').find('input[name="logo"]').remove()
                    this.options.maxFiles = this.options.maxFiles + 1
                }
            },
            init: function () {
                @if(isset($info) && $info->logo)
                var file = {!! json_encode($info->logo) !!}
                this.options.addedfile.call(this, file)
                this.options.thumbnail.call(this, file, '{{ $_SERVER['REMOTE_ADDR'] != "127.0.0.1" ? str_replace('localhost/storage', $_SERVER['SERVER_NAME'].'/system/storage/app/public' , $info->logo->getUrl('thumb')) : str_replace('localhost', 'localhost:8000', $info->logo->getUrl('thumb')) }}')
                file.previewElement.classList.add('dz-complete')
                $('form').append('<input type="hidden" name="logo" value="' + file.file_name + '">')
                this.options.maxFiles = this.options.maxFiles - 1
                @endif
            },
            error: function (file, response) {
                if ($.type(response) === 'string') {
                    var message = response //dropzone sends it's own error messages in string
                } else {
                    var message = response.errors.file
                }
                file.previewElement.classList.add('dz-error')
                _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
                _results = []
                for (_i = 0, _len = _ref.length; _i < _len; _i++) {
                    node = _ref[_i]
                    _results.push(node.textContent = message)
                }
                return _results
            }
        }

        Dropzone.options.footerDropzone = {
            url: '{{ route('admin.info.storeMedia') }}',
            acceptedFiles: '.jpeg,.jpg,.png,.gif,.webp',
            maxFiles: 1,
            addRemoveLinks: true,
            headers: {
                'X-CSRF-TOKEN': "{{ csrf_token() }}"
            },
            success: function (file, response) {
                $('form').find('input[name="footer"]').remove()
                $('form').append('<input type="hidden" name="footer" value="' + response.name + '">')
            },
            removedfile: function (file) {
                file.previewElement.remove()
                if (file.status !== 'error') {
                    $('form').find('input[name="footer"]').remove()
                    this.options.maxFiles = this.options.maxFiles + 1
                }
            },
            init: function () {
                @if(isset($info) && $info->footer)
                var file = {!! json_encode($info->footer) !!}
                this.options.addedfile.call(this, file)
                this.options.thumbnail.call(this, file, '{{ $_SERVER['REMOTE_ADDR'] != "127.0.0.1" ? str_replace('localhost/storage', $_SERVER['SERVER_NAME'].'/system/storage/app/public' , $info->footer->getUrl('thumb')) : str_replace('localhost', 'localhost:8000', $info->footer->getUrl('thumb')) }}')
                file.previewElement.classList.add('dz-complete')
                $('form').append('<input type="hidden" name="footer" value="' + file.file_name + '">')
                this.options.maxFiles = this.options.maxFiles - 1
                @endif
            },
            error: function (file, response) {
                if ($.type(response) === 'string') {
                    var message = response //dropzone sends it's own error messages in string
                } else {
                    var message = response.errors.file
                }
                file.previewElement.classList.add('dz-error')
                _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
                _results = []
                for (_i = 0, _len = _ref.length; _i < _len; _i++) {
                    node = _ref[_i]
                    _results.push(node.textContent = message)
                }
                return _results
            }
        }

        Dropzone.options.faviconDropzone = {
            url: '{{ route('admin.info.storeMedia') }}',
            acceptedFiles: '.jpeg,.jpg,.png,.gif,.webp',
            maxFiles: 1,
            addRemoveLinks: true,
            headers: {
                'X-CSRF-TOKEN': "{{ csrf_token() }}"
            },
            success: function (file, response) {
                $('form').find('input[name="favicon"]').remove()
                $('form').append('<input type="hidden" name="favicon" value="' + response.name + '">')
            },
            removedfile: function (file) {
                file.previewElement.remove()
                if (file.status !== 'error') {
                    $('form').find('input[name="favicon"]').remove()
                    this.options.maxFiles = this.options.maxFiles + 1
                }
            },
            init: function () {
                @if(isset($info) && $info->favicon)
                var file = {!! json_encode($info->favicon) !!}
                this.options.addedfile.call(this, file)
                this.options.thumbnail.call(this, file, '{{ $_SERVER['REMOTE_ADDR'] != "127.0.0.1" ? str_replace('localhost/storage', $_SERVER['SERVER_NAME'].'/system/storage/app/public' , $info->favicon->getUrl('thumb')) : str_replace('localhost', 'localhost:8000', $info->favicon->getUrl('thumb')) }}')
                file.previewElement.classList.add('dz-complete')
                $('form').append('<input type="hidden" name="favicon" value="' + file.file_name + '">')
                this.options.maxFiles = this.options.maxFiles - 1
                @endif
            },
            error: function (file, response) {
                if ($.type(response) === 'string') {
                    var message = response //dropzone sends it's own error messages in string
                } else {
                    var message = response.errors.file
                }
                file.previewElement.classList.add('dz-error')
                _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
                _results = []
                for (_i = 0, _len = _ref.length; _i < _len; _i++) {
                    node = _ref[_i]
                    _results.push(node.textContent = message)
                }
                return _results
            }
        }
    </script>
@stop

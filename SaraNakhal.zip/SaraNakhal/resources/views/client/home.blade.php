@extends('layouts.app')
@section('content')

    <section class="Stories">
        <div class="container">
            <div class="StoriesIntroduction" data-aos="fade-down" data-aos-duration="1000">
                <h1>{{ $GlobalInfo->article ?? '' }}</h1>
            </div>

            <div class="StoriesGH">
                @foreach($articles as $key => $article)
                    <div class="StoriesItem" data-aos="fade-up" data-aos-duration="1000"
                         data-aos-delay="{{ $key+1 }}00">
                        <img class="StoriesItemThumb"
                             src="{{ $article->photo->thumbnail ?? '' }}"
                             alt="{{ $article->title ?? '' }} - {{ $GlobalInfo->title ?? '' }} - {{ $article->description ?? '' }}">
                        <div class="StoriesItemText">
                            <h4>{{ $article->title ?? '' }}</h4>
                            <label>
                                <i class="fa fa-calendar-alt"></i>
                                {{ date('d F Y', strtotime($article->created_at)) }}
                            </label>
                            <p>
                                {{ $article->description ?? '' }}
                            </p>
                            <button type="button" onclick="$(this).find('a')[0].click()">
                                <a href="{{ route('articles.show', [$article->id]) }}" class="d-none"></a>
                                Read More
                                <div class="setbg" rel="{{ asset('') }}SaraTemplate/Requirements/IMG/Right.png"></div>
                            </button>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </section>
@endsection
@section('scripts')
    @parent

@endsection

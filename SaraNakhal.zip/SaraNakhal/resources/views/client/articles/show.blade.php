@extends('layouts.app')
@section('content')
    <section class="StoryShow">
        <div class="container">
            <div class="StoryShowInner">
                <img src="{{ $article->photo->url ?? '' }}" class="StoryShowImage" alt="{{ $article->title ?? '' }} - {{ $GlobalInfo->title ?? '' }} - {{ $article->description ?? '' }}">
                <div class="StoryShowMain">
                    <h1> {{ $article->title ?? '' }} </h1>
                    <p>
                        {{ $article->description ?? '' }}
                    </p>
                </div>

                <div class="StoryShowFullDescription">
                    {!! $article->full_description ?? '' !!}
                </div>
            </div>
        </div>
    </section>
@endsection
@section('scripts')
    @parent

@endsection

@extends('layouts.app')
@section('styles')
    @parent
    <style>
        header ,footer{
            display: none!important;
        }
    </style>
@endsection
@section('content')
    <div class="QuoteSuccess">
        <div class="QuoteSuccessInner">
            <div class="QuoteSuccessDiv">
                <img class="PageErrorArt" src="{{ asset('') }}HBTransit/Requirements/IMG/Error.webp" alt="{{ $GlobalInfo->title ?? '' }}">
                <p>
                    Oops! Something went wrong. It seems the page you are looking for is missing or broken.
                </p>
                <label>
                    Error Code: <u>401</u>
                </label>

                <button type="button" onclick="$(this).find('a')[0].click()">
                    <a href="{{ route('home') }}" class="d-none"></a>
                    <i class="fas fa-home"></i>
                    Return Home
                </button>
            </div>

        </div>
    </div>
@endsection

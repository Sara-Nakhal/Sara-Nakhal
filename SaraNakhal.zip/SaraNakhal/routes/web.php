<?php

Route::group(['middleware' => ['auth']], function () {
    Route::get('2fa/verify', 'TwoFactorController@show')->name('2fa.verify.show');
    Route::get('enable-2fa', 'TwoFactorController@enable')->name('enable-2fa');
    Route::post('2fa/verify', 'TwoFactorController@verify')->name('2fa.verify');
});

Route::get('/', 'Client\HomePageController@index')->name('home');

Route::get('articles/{article}', 'Client\ArticlesController@show')->name('articles.show');


Route::redirect('/home', '/admin');
Auth::routes(['register' => false]);

Route::group(['prefix' => 'admin', 'as' => 'admin.', 'namespace' => 'Admin', 'middleware' => ['auth', '2fa']], function () {

    Route::get('/', 'HomeController@index')->name('home');

    // Permissions
    Route::delete('permissions/destroy', 'PermissionsController@massDestroy')->name('permissions.massDestroy');
    Route::resource('permissions', 'PermissionsController');

    // Roles
    Route::delete('roles/destroy', 'RolesController@massDestroy')->name('roles.massDestroy');
    Route::resource('roles', 'RolesController');

    // Users
    Route::delete('users/destroy', 'UsersController@massDestroy')->name('users.massDestroy');
    Route::resource('users', 'UsersController');

    // articles
    Route::get('articles/deleted', 'ArticleController@deleted')->name('articles.deleted');
    Route::get('articles/restore/{article}', 'ArticleController@restore')->name('articles.restore');
    Route::delete('articles/destroy', 'ArticleController@massDestroy')->name('articles.massDestroy');
    Route::post('articles/media', 'ArticleController@storeMedia')->name('articles.storeMedia');
    Route::resource('articles', 'ArticleController');

    // Categories
    Route::delete('categories/destroy', 'CategoryController@massDestroy')->name('categories.massDestroy');
    Route::resource('categories', 'CategoryController');

    // Info
    Route::delete('info/destroy', 'InfoController@massDestroy')->name('info.massDestroy');
    Route::post('info/media', 'InfoController@storeMedia')->name('info.storeMedia');
    Route::resource('info', 'InfoController');

});
